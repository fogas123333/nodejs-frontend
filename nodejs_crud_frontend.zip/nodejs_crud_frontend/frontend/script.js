const API_BASE_URL = 'http://localhost:3000/api';

const productForm = document.getElementById('productForm');
const productsGrid = document.getElementById('productsGrid')
const emptystate = document.getElementById('emptystate')
const productsLoading = document.getElementById('productsLoading')
const refreshButton = document.getElementById('refreshButton')
const clearButton = document.getElementById('clearButton')
const toast = document.getElementById('toast')
const toastMessage = document.getElementById('toastMessage')
const loadingSpinner = document.getElementById('LoadingSpinner')
const submitText = document.getElementById('submitText')

function showToast(message, type = 'sucess'){
    const toastEl = document.getElementById('toast');
    toastMessage.textContent = message;
    toastEl.firstElementChild.classList.remove('bg-green-500','bg-red-500','bg-yellow-500');
    if (type === 'error'){
        toastEl.firstElementChild.classList.add('bg-red-500');
    }else if (type === 'warning'){
        toastEl.firstElementChild.classList.add('bg-yellow-500');
    }else{
        toastEl.firstElementChild.classList.add('bg-green-500');
    }
    toastEl.classList.remove('hidden');
    setTimeout(()=>{
        toastEl.classList.add('hidden');
        },3000);
    }

        function processImageUrl(url){
            if(!url) return '';
            if(url.includes('drive.google.com')){
                let fileId = null;
                let match = url.match(/file\/d\/([a-zA-z0-9_-]+)/);
                if (match){
                    fileId = match[1];
                }
                if(!fileId){
                    match = url.match(/[?&]id=(a-zA-z0-9_-]+)/);
                    if (match){
                        fileId = match[1];
                    }
                }
                if (fileId){
                    return `https://1h3.googleusercontent.com/d/${fileId}`;
                }
            }
            return url;
        }

        function createProductCard(product){
            const imageUrl = processimageUrl(product.image);
            const imageElement = imageUrl ?
            `<img
            src="${imageUrl}"
            alt="${product.nome}"
            class="w-full h-48 product-image"
            onerror="this.style.display='none';
            this.nextElementSibling.style.display='flex'"
            >` :'';
            const imagePlaceholder = `
            <div class="w-full h-48 image-placeholder" style ="display:${imageUrl ? 'nome' : 'flex'}">
            📦
            <div/>
            `;
        }